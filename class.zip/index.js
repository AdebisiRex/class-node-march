// import express from "express" //es6
const express = require("express"); //es5

const app = express();

app.use(express.urlencoded({ extended: true }));
app.set("view engine", "ejs");


let anchorArray =[]
app.listen(2350, () => {
  console.log("I have started listening");
});

app.get("/", (request, response) => {
  // response.send({message: "Interesting things are about to happen"})
  response.render("index", {
    message: "This is a message",
    array: ["bmw", "lambo", "camry"],
  });
  // response.sendFile(__dirname + "/index.html");
  // response.status(503).json({ message: "Hello Olamilekan" });
});

app.get("/login", (req, res) => {
  res.redirect("https://www.google.com");
  // res.send("This is the login page");
});

app.get("/search", (req, res) => {
  console.log(req.query);
  res.send("Search  ing happened");
});

//using param
app.get("/get-user-by-id/:id", (req, res) => {
  const { id } = req.params;

  res.send("This is the Get User by Id for " + id);
});

app.post("/create-user", (req, res) => {
  console.log(req.body);
  // res.send("This is the login page");

  res.render("accout-created");
  // res.sendFile(__dirname + "/log.html");
});
app.patch("/patch", () => {
  console.log("We are here  patching");
});
